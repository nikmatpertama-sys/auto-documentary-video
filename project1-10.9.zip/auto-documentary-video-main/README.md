# Auto Documentary Video

Automated vertical documentary generator. It builds a scene plan, searches for relevant real-world footage, performs visual verification, generates narration and captions, and renders the final video with FFmpeg.

## Footage sources

Search priority: Internet Archive, Wikimedia Commons, NASA, Pexels, then Pixabay. Internet Archive results are admitted only when metadata explicitly indicates CC0, CC BY, or Public Domain. Wikimedia Commons results are license-filtered. NASA assets may require checking third-party credits. Always verify the exact source-page license and attribution requirements before publishing.

## First-time GitHub setup

1. Replace `.github/workflows/render.yml` on the target branch with the supplied `render.yml` file and commit it.
2. Upload the project ZIP to the repository root (not inside a subfolder) and commit it. The ZIP filename may be arbitrary; it only needs a `.zip` extension.
3. Open **Actions → Hybrid Documentary Generator → Run workflow**, enter the topic, and start the run.

The workflow contains a self-contained ZIP reader, so the first setup does **not** require `apply_project_zip.py` to already exist in the branch. It selects the newest root-level ZIP by the latest commit affecting that ZIP, accepts a flat project or one wrapper folder such as `auto-documentary-video-main/`, and overlays the files into the Actions workspace for that run.

The ZIP is not extracted back into the GitHub branch. It is applied only inside the runner and removed from that runner's temporary workspace. The committed ZIP remains in the repository, so it will be applied again on future runs until you delete it or replace it with a newer ZIP.

A ZIP attached only to a ChatGPT conversation or stored on a phone is not visible to GitHub Actions. It must be uploaded and committed to the repository root.

## ZIP safety checks

The workflow rejects path traversal, absolute or drive-qualified paths, duplicate archive paths, symlinks and special files, encrypted entries, excessive archive sizes, excessive expanded sizes, and suspicious compression ratios. The ZIP must contain `main.py` at its root or inside one wrapper folder. ZIPs are executable project code; upload only packages you trust.

## Required GitHub Secrets

Add at least one AI provider key: `GEMINI_API_KEY`, `GROQ_API_KEY`, or `OPENROUTER_API_KEY`. `PIXABAY_API_KEY` and `PEXELS_API_KEY` are optional fallbacks. Internet Archive, Wikimedia Commons, and NASA searches do not require API keys.

## Output

The workflow uploads `documentary.mp4`, `plan.json`, `credits.txt`, `timing.json`, and the voice-over/caption files as a GitHub Actions artifact.


## Version 10.9 — Scriptwriter and footage fallback upgrade

- Adds `SCRIPTWRITER_MASTER_PROMPT.md` as the generator's single-role professional documentary scriptwriter prompt.
- Adds a silent factual-claim audit to the generation instructions without adding a second API request. The model is explicitly forbidden from inventing sources or claiming live research it did not perform.
- Normalizes repeated words in footage queries and adds targeted fallback search variants only when a scene's candidate pool is sparse.
- Allows a previously accepted clip to be reused only as a last resort, and only after it is visually re-checked against the new scene. Reuse is disclosed in `plan.json` and `credits.txt`.
- Keeps visual verification enabled; no metadata-only bypass or unrelated-footage substitution is introduced.
